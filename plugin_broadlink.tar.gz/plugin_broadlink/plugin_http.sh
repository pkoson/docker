nohup python /Domoticz/plugins/BroadlinkRM2/plugin_http.py $1 $2 $3 & 
